# Master
Master Thesis. Simulation of Nanocubes forming a Mesocrystal

evap: Modelling evaporation of the solvent in lammps. Both the solvent and cubes are body style particles. runtime might be bad.
